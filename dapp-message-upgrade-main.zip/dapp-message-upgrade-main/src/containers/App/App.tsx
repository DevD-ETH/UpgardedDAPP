import React, { useEffect, useState, useCallback } from "react";
import { ethers } from "ethers";
import SampleContract from "../../artifacts/contracts/Sample.sol/Sample.json";
import {
  Wallet,
  Send,
  History,
  User,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader,
  ExternalLink,
  Shield,
  MessageSquare,
  Copy,
  Check,
  Sun,
  Moon,
  Search,
  Zap,
  Heart,
  ThumbsUp,
  Smile,
  PartyPopper,
  Flame,
  DollarSign
} from "lucide-react";

const contractAddress = process.env.REACT_APP_CONTRACT_ADDRESS || "0x5FbDB2315678afecb367f032d93F642f64180aa3";

const REACTIONS: { [key: string]: string } = {
  like: "👍",
  love: "❤️",
  laugh: "😂",
  wow: "😮",
  party: "🎉"
};

interface MessageEntry {
  content: string;
  timestamp: ethers.BigNumber;
  author: string;
  tips: ethers.BigNumber;
  reactions: { [key: string]: number };
}

interface Toast {
  id: number;
  message: string;
  type: "success" | "error" | "info";
}

interface Theme {
  isDark: boolean;
  colors: {
    bg: string;
    card: string;
    text: string;
    textMuted: string;
    primary: string;
    accent: string;
    border: string;
    inputBg: string;
  };
}

const lightTheme: Theme["colors"] = {
  bg: "#0284c7",
  card: "#0ea5e9",
  text: "#ffffff",
  textMuted: "#e0f2fe",
  primary: "#ffffff",
  accent: "#7dd3fc",
  border: "#38bdf8",
  inputBg: "#0369a1"
};

const darkTheme: Theme["colors"] = {
  bg: "#0c4a6e",
  card: "#075985",
  text: "#ffffff",
  textMuted: "#bae6fd",
  primary: "#38bdf8",
  accent: "#7dd3fc",
  border: "#0284c7",
  inputBg: "#0369a1"
};

const App: React.FC = () => {
  const [message, setMessage] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [account, setAccount] = useState<string | null>(null);
  const [owner, setOwner] = useState<string | null>(null);
  const [messageCount, setMessageCount] = useState<number>(0);
  const [messageHistory, setMessageHistory] = useState<MessageEntry[]>([]);
  const [filteredHistory, setFilteredHistory] = useState<MessageEntry[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"message" | "history">("message");
  const [isDark, setIsDark] = useState(true);
  const [gasEstimate, setGasEstimate] = useState<string | null>(null);
  const [ensNames, setEnsNames] = useState<{ [key: string]: string | null }>({});
  const [tipAmount, setTipAmount] = useState("");
  const [tippingMessageIndex, setTippingMessageIndex] = useState<number | null>(null);

  const theme = isDark ? darkTheme : lightTheme;

  const addToast = useCallback((message: string, type: Toast["type"]) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  // ENS Resolution
  const resolveENS = async (address: string, provider: ethers.providers.Provider) => {
    try {
      const ensName = await provider.lookupAddress(address);
      if (ensName) {
        setEnsNames(prev => ({ ...prev, [address]: ensName }));
      }
    } catch (err) {
      console.log("ENS not found for", address);
    }
  };

  const getDisplayName = (address: string) => {
    return ensNames[address] || formatAddress(address);
  };

  const requestAccount = async () => {
    if (typeof window.ethereum === "undefined") {
      addToast("MetaMask not detected. Please install MetaMask extension.", "error");
      window.open("https://metamask.io/download/", "_blank");
      return null;
    }
    try {
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      setAccount(accounts[0]);
      addToast("Wallet connected!", "success");
      return accounts[0];
    } catch (err) {
      addToast("Failed to connect wallet", "error");
      return null;
    }
  };

  const getContractData = async () => {
    if (typeof window.ethereum === "undefined") return;

    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const sampleContract = new ethers.Contract(
      contractAddress,
      SampleContract.abi,
      provider
    );

    try {
      const [msg, own, count, historyData] = await Promise.all([
        sampleContract.getMessage(),
        sampleContract.owner(),
        sampleContract.messageCount(),
        sampleContract.getMessageHistory()
      ]);

      setMessage(msg);
      setOwner(own);
      setMessageCount(count.toNumber());

      // Parse history data (now returns tuples)
      const [contents, timestamps, authors, tips] = historyData;
      const history: MessageEntry[] = [];

      for (let i = 0; i < contents.length; i++) {
        const reactions: { [key: string]: number } = {};
        for (const [key, emoji] of Object.entries(REACTIONS)) {
          try {
            const count = await sampleContract.getReactionCount(i, key);
            if (count.gt(0)) reactions[key] = count.toNumber();
          } catch (e) { }
        }

        history.push({
          content: contents[i],
          timestamp: timestamps[i],
          author: authors[i],
          tips: tips[i],
          reactions
        });

        // Resolve ENS for each unique author
        resolveENS(authors[i], provider);
      }

      setMessageHistory(history);
      setFilteredHistory(history);
      resolveENS(own, provider);
    } catch (err) {
      console.error("Error fetching contract data:", err);
    }
  };

  // Real-time event listeners
  useEffect(() => {
    if (typeof window.ethereum === "undefined") return;

    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const sampleContract = new ethers.Contract(
      contractAddress,
      SampleContract.abi,
      provider
    );

    // Listen for MessageUpdated events
    sampleContract.on("MessageUpdated", (oldMessage, newMessage, updatedBy, timestamp) => {
      addToast("New message posted!", "info");
      getContractData();
    });

    // Listen for TipSent events
    sampleContract.on("TipSent", (from, to, amount, messageIndex) => {
      const ethAmount = ethers.utils.formatEther(amount);
      addToast(`${formatAddress(from)} tipped ${ethAmount} ETH!`, "success");
      getContractData();
    });

    // Listen for ReactionAdded events
    sampleContract.on("ReactionAdded", (user, messageIndex, reaction, count) => {
      getContractData();
    });

    return () => {
      sampleContract.removeAllListeners();
    };
  }, []);

  // Gas estimation
  const estimateGas = async () => {
    if (!inputValue.trim() || typeof window.ethereum === "undefined") return;

    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(contractAddress, SampleContract.abi, signer);

      const estimatedGas = await contract.estimateGas.setMessage(inputValue);
      const gasPrice = await provider.getGasPrice();
      const cost = estimatedGas.mul(gasPrice);
      setGasEstimate(ethers.utils.formatEther(cost));
    } catch (err) {
      setGasEstimate(null);
    }
  };

  useEffect(() => {
    estimateGas();
  }, [inputValue]);

  const setSampleContractMessage = async () => {
    if (!inputValue.trim()) return;

    const connectedAccount = account || await requestAccount();
    if (!connectedAccount) return;

    setLoading(true);
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(contractAddress, SampleContract.abi, signer);

      const transaction = await contract.setMessage(inputValue);
      await transaction.wait();

      addToast("Message updated successfully!", "success");
      await getContractData();
      setInputValue("");
      setGasEstimate(null);
    } catch (err: any) {
      console.error(err);
      addToast(err.message || "Failed to update message", "error");
    } finally {
      setLoading(false);
    }
  };

  const sendTip = async (messageIndex: number) => {
    if (!tipAmount || parseFloat(tipAmount) <= 0) return;

    const connectedAccount = account || await requestAccount();
    if (!connectedAccount) return;

    setLoading(true);
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(contractAddress, SampleContract.abi, signer);

      const tx = await contract.tipMessageAuthor(messageIndex, {
        value: ethers.utils.parseEther(tipAmount)
      });
      await tx.wait();

      addToast(`Tipped ${tipAmount} ETH!`, "success");
      setTipAmount("");
      setTippingMessageIndex(null);
      await getContractData();
    } catch (err: any) {
      console.error(err);
      addToast(err.message || "Failed to send tip", "error");
    } finally {
      setLoading(false);
    }
  };

  const addReaction = async (messageIndex: number, reaction: string) => {
    const connectedAccount = account || await requestAccount();
    if (!connectedAccount) return;

    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(contractAddress, SampleContract.abi, signer);

      const tx = await contract.addReaction(messageIndex, reaction);
      await tx.wait();

      addToast(`Reacted ${reaction}!`, "success");
      await getContractData();
    } catch (err: any) {
      addToast(err.message || "Failed to add reaction", "error");
    }
  };

  // Search filter
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredHistory(messageHistory);
      return;
    }

    const filtered = messageHistory.filter(entry =>
      entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (ensNames[entry.author]?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false)
    );
    setFilteredHistory(filtered);
  }, [searchQuery, messageHistory, ensNames]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  const formatTimestamp = (timestamp: ethers.BigNumber) => {
    const date = new Date(timestamp.toNumber() * 1000);
    return date.toLocaleString();
  };

  const formatEth = (wei: ethers.BigNumber) => {
    const eth = ethers.utils.formatEther(wei);
    return parseFloat(eth).toFixed(4);
  };

  useEffect(() => {
    getContractData();

    if (window.ethereum) {
      window.ethereum.on("accountsChanged", (accounts: string[]) => {
        setAccount(accounts[0] || null);
      });
    }
  }, []);

  const isOwner = account && owner && account.toLowerCase() === owner.toLowerCase();

  return (
    <div style={{ ...styles.container, background: theme.bg }}>
      <div style={styles.toastContainer}>
        {toasts.map(toast => (
          <div key={toast.id} style={{ ...styles.toast(toast.type), background: toast.type === "success" ? "#065f46" : toast.type === "error" ? "#991b1b" : "#1e40af" }}>
            {toast.type === "success" && <CheckCircle size={18} />}
            {toast.type === "error" && <AlertCircle size={18} />}
            {toast.type === "info" && <MessageSquare size={18} />}
            <span>{toast.message}</span>
          </div>
        ))}
      </div>

      <div style={{ ...styles.card, background: theme.card }}>
        <div style={styles.header}>
          <div style={styles.titleRow}>
            <MessageSquare size={28} color={theme.primary} />
            <h1
              style={{
                ...styles.title,
                color: theme.primary
              }}
            >
              Message DApp Project Update
            </h1>          </div>
          <p style={{ ...styles.subtitle, color: theme.textMuted }}>Decentralized message storage on Ethereum</p>
        </div>

        <div style={styles.walletSection}>
          <div style={styles.walletRow}>
            {account ? (
              <div style={styles.walletConnected}>
                <div style={{ ...styles.walletBadge, background: `${theme.primary}20`, color: theme.primary }}>
                  <div style={styles.onlineIndicator} />
                  <Wallet size={16} />
                  <span style={styles.address}>{getDisplayName(account)}</span>
                  <button onClick={() => copyToClipboard(account)} style={styles.iconButton}>
                    {copied ? <Check size={14} color="#22c55e" /> : <Copy size={14} color={theme.textMuted} />}
                  </button>
                </div>
                {isOwner && (
                  <div style={{ ...styles.ownerBadge, background: "rgba(168, 85, 247, 0.15)", color: "#a855f7" }}>
                    <Shield size={14} />
                    <span>Owner</span>
                  </div>
                )}
              </div>
            ) : (
              <button onClick={requestAccount} style={{ ...styles.connectButton, background: theme.primary }}>
                <Wallet size={18} />
                Connect Wallet
              </button>
            )}

            <button onClick={() => setIsDark(!isDark)} style={{ ...styles.themeToggle, background: theme.inputBg, color: theme.text }}>
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>

        <div style={{ ...styles.tabs, background: theme.inputBg }}>
          <button
            onClick={() => setActiveTab("message")}
            style={{ ...styles.tab(activeTab === "message", isDark), background: activeTab === "message" ? `${theme.primary}30` : "transparent", color: activeTab === "message" ? theme.primary : theme.textMuted }}
          >
            <Send size={16} />
            Message
          </button>
          <button
            onClick={() => setActiveTab("history")}
            style={{ ...styles.tab(activeTab === "history", isDark), background: activeTab === "history" ? `${theme.primary}30` : "transparent", color: activeTab === "history" ? theme.primary : theme.textMuted }}
          >
            <History size={16} />
            History ({filteredHistory.length})
          </button>
        </div>

        {activeTab === "message" ? (
          <div style={styles.tabContent}>
            <div style={{ ...styles.currentMessage, background: theme.inputBg, border: `1px solid ${theme.border}` }}>
              <div style={styles.messageHeader}>
                <Clock size={16} color={theme.textMuted} />
                <span style={{ ...styles.label, color: theme.textMuted }}>Current Message</span>
              </div>
              <p style={{ ...styles.messageText, color: theme.text }}>{message || "Loading..."}</p>
            </div>

            <div style={styles.inputSection}>
              <label style={{ ...styles.label, color: theme.textMuted }}>Update Message</label>
              <div style={styles.inputRow}>
                <input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && setSampleContractMessage()}
                  placeholder="Enter new message..."
                  style={{ ...styles.input, background: theme.inputBg, border: `2px solid ${theme.border}`, color: theme.text }}
                  disabled={loading}
                />
                <button
                  onClick={setSampleContractMessage}
                  disabled={!inputValue.trim() || loading}
                  style={{ ...styles.sendButton(!!inputValue.trim() && !loading, isDark), background: !!inputValue.trim() && !loading ? theme.primary : "rgba(100, 116, 139, 0.3)" }}
                >
                  {loading ? <Loader size={18} style={styles.spinner} /> : <Send size={18} />}
                </button>
              </div>
              {gasEstimate && (
                <div style={styles.gasEstimate}>
                  <Zap size={14} color={theme.textMuted} />
                  <span style={{ color: theme.textMuted }}>Estimated gas: {parseFloat(gasEstimate).toFixed(6)} ETH</span>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div style={styles.tabContent}>
            <div style={styles.searchSection}>
              <div style={{ ...styles.searchBox, background: theme.inputBg, border: `1px solid ${theme.border}` }}>
                <Search size={16} color={theme.textMuted} />
                <input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search messages or authors..."
                  style={{ ...styles.searchInput, color: theme.text }}
                />
              </div>
            </div>

            <div style={styles.historyList}>
              {filteredHistory.length === 0 ? (
                <div style={styles.emptyState}>
                  <History size={48} color={theme.textMuted} />
                  <p style={{ color: theme.textMuted }}>No messages found</p>
                </div>
              ) : (
                [...filteredHistory].reverse().map((entry, index) => {
                  const actualIndex = filteredHistory.length - 1 - index;
                  return (
                    <div key={actualIndex} style={{ ...styles.historyItem, background: theme.inputBg, border: `1px solid ${theme.border}` }}>
                      <div style={styles.historyHeader}>
                        <div style={styles.historyMeta}>
                          <User size={14} color={theme.textMuted} />
                          <span style={{ ...styles.historyAddress, color: theme.primary }}>{getDisplayName(entry.author)}</span>
                        </div>
                        <span style={{ ...styles.historyTime, color: theme.textMuted }}>{formatTimestamp(entry.timestamp)}</span>
                      </div>
                      <p style={{ ...styles.historyMessage, color: theme.text }}>{entry.content}</p>

                      {/* Tips */}
                      <div style={styles.tipSection}>
                        <div style={styles.tipDisplay}>
                          <DollarSign size={14} color="#22c55e" />
                          <span style={{ color: "#22c55e", fontSize: "13px" }}>{formatEth(entry.tips)} ETH received</span>
                        </div>
                        {tippingMessageIndex === actualIndex ? (
                          <div style={styles.tipInputRow}>
                            <input
                              type="number"
                              value={tipAmount}
                              onChange={(e) => setTipAmount(e.target.value)}
                              placeholder="ETH amount"
                              style={{ ...styles.tipInput, background: theme.inputBg, color: theme.text, border: `1px solid ${theme.border}` }}
                              step="0.001"
                              min="0"
                            />
                            <button onClick={() => sendTip(actualIndex)} style={styles.tipButton}>
                              Send
                            </button>
                            <button onClick={() => setTippingMessageIndex(null)} style={styles.tipCancel}>
                              ✕
                            </button>
                          </div>
                        ) : (
                          <button onClick={() => setTippingMessageIndex(actualIndex)} style={styles.tipAction}>
                            <DollarSign size={14} />
                            Tip Author
                          </button>
                        )}
                      </div>

                      {/* Reactions */}
                      <div style={styles.reactions}>
                        {Object.entries(REACTIONS).map(([key, emoji]) => {
                          const count = entry.reactions[key] || 0;
                          return (
                            <button
                              key={key}
                              onClick={() => addReaction(actualIndex, key)}
                              style={{
                                ...styles.reaction,
                                background: count > 0 ? `${theme.primary}20` : "transparent",
                                border: `1px solid ${count > 0 ? theme.primary : theme.border}`
                              }}
                            >
                              <span>{emoji}</span>
                              {count > 0 && <span style={{ ...styles.reactionCount, color: theme.primary }}>{count}</span>}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        <div style={{ ...styles.footer, borderTop: `1px solid ${theme.border}` }}>
          <div style={styles.stats}>
            <div style={styles.stat}>
              <span style={{ ...styles.statLabel, color: theme.textMuted }}>Total Messages</span>
              <span style={{ ...styles.statValue, color: theme.text }}>{messageCount}</span>
            </div>
            <div style={styles.stat}>
              <span style={{ ...styles.statLabel, color: theme.textMuted }}>Contract</span>
              <a href={`https://etherscan.io/address/${contractAddress}`} target="_blank" rel="noopener noreferrer" style={{ ...styles.contractLink, color: theme.primary }}>
                {formatAddress(contractAddress)}
                <ExternalLink size={12} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles: { [key: string]: any } = {
  container: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "flex-start",
    padding: "20px",
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    transition: "all 0.3s ease",
  },
  toastContainer: {
    position: "fixed",
    top: "20px",
    right: "20px",
    zIndex: 1000,
    display: "flex",
    flexDirection: "column" as const,
    gap: "10px",
  },
  toast: (type: string) => ({
    display: "flex",
    alignItems: "center",
    gap: "10px",
    padding: "12px 20px",
    borderRadius: "10px",
    color: "#fff",
    fontSize: "14px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
    animation: "slideIn 0.3s ease",
  }),
  card: {
    width: "100%",
    maxWidth: "550px",
    borderRadius: "20px",
    padding: "30px",
    boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.05)",
    transition: "all 0.3s ease",
  },
  header: {
    textAlign: "center" as const,
    marginBottom: "24px",
  },
  titleRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "12px",
    marginBottom: "8px",
  },
  title: {
    margin: 0,
    fontSize: "28px",
    fontWeight: 700,
  },
  subtitle: {
    margin: 0,
    fontSize: "14px",
  },
  walletSection: {
    marginBottom: "24px",
  },
  walletRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  walletConnected: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
  },
  walletBadge: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    padding: "10px 16px",
    borderRadius: "10px",
    fontSize: "14px",
  },
  onlineIndicator: {
    width: "8px",
    height: "8px",
    background: "#22c55e",
    borderRadius: "50%",
    boxShadow: "0 0 8px #22c55e",
  },
  iconButton: {
    background: "none",
    border: "none",
    cursor: "pointer",
    padding: "4px",
    display: "flex",
    alignItems: "center",
  },
  ownerBadge: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    padding: "6px 12px",
    borderRadius: "8px",
    fontSize: "12px",
    fontWeight: 600,
  },
  connectButton: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    padding: "12px 24px",
    border: "none",
    borderRadius: "12px",
    color: "#fff",
    fontSize: "15px",
    fontWeight: 600,
    cursor: "pointer",
    transition: "all 0.2s",
    boxShadow: "0 4px 20px rgba(59, 130, 246, 0.3)",
  },
  themeToggle: {
    padding: "10px",
    border: "none",
    borderRadius: "10px",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.2s",
  },
  address: {
    fontFamily: "monospace",
    fontWeight: 500,
  },
  tabs: {
    display: "flex",
    gap: "8px",
    marginBottom: "20px",
    padding: "4px",
    borderRadius: "12px",
  },
  tab: (active: boolean, isDark: boolean) => ({
    flex: 1,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
    padding: "10px",
    border: "none",
    borderRadius: "10px",
    fontSize: "14px",
    fontWeight: 600,
    cursor: "pointer",
    transition: "all 0.2s",
  }),
  tabContent: {
    animation: "fadeIn 0.3s ease",
  },
  currentMessage: {
    padding: "20px",
    borderRadius: "16px",
    marginBottom: "20px",
  },
  messageHeader: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    marginBottom: "12px",
  },
  label: {
    display: "block",
    fontSize: "13px",
    fontWeight: 600,
    textTransform: "uppercase" as const,
    letterSpacing: "0.5px",
  },
  messageText: {
    margin: 0,
    fontSize: "18px",
    fontWeight: 500,
    lineHeight: 1.5,
    wordBreak: "break-word" as const,
  },
  inputSection: {
    marginBottom: "16px",
  },
  inputRow: {
    display: "flex",
    gap: "10px",
    marginTop: "10px",
  },
  input: {
    flex: 1,
    padding: "14px 18px",
    borderRadius: "12px",
    fontSize: "15px",
    outline: "none",
    transition: "all 0.2s",
  },
  sendButton: (enabled: boolean, isDark: boolean) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: "50px",
    height: "50px",
    border: "none",
    borderRadius: "12px",
    color: "#fff",
    cursor: enabled ? "pointer" : "not-allowed",
    transition: "all 0.2s",
  }),
  spinner: {
    animation: "spin 1s linear infinite",
  },
  gasEstimate: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    marginTop: "8px",
    fontSize: "12px",
  },
  searchSection: {
    marginBottom: "16px",
  },
  searchBox: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    padding: "12px 16px",
    borderRadius: "12px",
  },
  searchInput: {
    flex: 1,
    background: "transparent",
    border: "none",
    outline: "none",
    fontSize: "14px",
  },
  historyList: {
    maxHeight: "400px",
    overflowY: "auto" as const,
    display: "flex",
    flexDirection: "column" as const,
    gap: "12px",
  },
  historyItem: {
    padding: "16px",
    borderRadius: "12px",
  },
  historyHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "10px",
  },
  historyMeta: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
  },
  historyAddress: {
    fontSize: "13px",
    fontFamily: "monospace",
  },
  historyTime: {
    fontSize: "12px",
  },
  historyMessage: {
    margin: 0,
    fontSize: "15px",
    lineHeight: 1.5,
    wordBreak: "break-word" as const,
    marginBottom: "12px",
  },
  emptyState: {
    display: "flex",
    flexDirection: "column" as const,
    alignItems: "center",
    padding: "40px",
    gap: "12px",
  },
  footer: {
    marginTop: "24px",
    paddingTop: "20px",
  },
  stats: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  stat: {
    display: "flex",
    flexDirection: "column" as const,
    gap: "4px",
  },
  statLabel: {
    fontSize: "12px",
  },
  statValue: {
    fontSize: "18px",
    fontWeight: 700,
  },
  contractLink: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    fontSize: "13px",
    fontFamily: "monospace",
    textDecoration: "none",
    transition: "color 0.2s",
  },
  tipSection: {
    display: "flex",
    flexDirection: "column" as const,
    gap: "8px",
    marginTop: "12px",
    paddingTop: "12px",
    borderTop: "1px solid rgba(255,255,255,0.1)",
  },
  tipDisplay: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
  },
  tipInputRow: {
    display: "flex",
    gap: "8px",
  },
  tipInput: {
    flex: 1,
    padding: "8px 12px",
    borderRadius: "8px",
    fontSize: "14px",
    outline: "none",
  },
  tipButton: {
    padding: "8px 16px",
    background: "#22c55e",
    border: "none",
    borderRadius: "8px",
    color: "#fff",
    fontWeight: 600,
    cursor: "pointer",
  },
  tipCancel: {
    padding: "8px 12px",
    background: "transparent",
    border: "none",
    color: "#94a3b8",
    cursor: "pointer",
    fontSize: "14px",
  },
  tipAction: {
    display: "flex",
    alignItems: "center",
    gap: "6px",
    padding: "8px 16px",
    background: "transparent",
    border: "1px solid #22c55e",
    borderRadius: "8px",
    color: "#22c55e",
    fontSize: "13px",
    cursor: "pointer",
    alignSelf: "flex-start",
  },
  reactions: {
    display: "flex",
    gap: "8px",
    marginTop: "8px",
  },
  reaction: {
    display: "flex",
    alignItems: "center",
    gap: "4px",
    padding: "6px 10px",
    borderRadius: "20px",
    cursor: "pointer",
    transition: "all 0.2s",
    fontSize: "16px",
  },
  reactionCount: {
    fontSize: "12px",
    fontWeight: 600,
  },
};

const styleSheet = document.createElement("style");
styleSheet.textContent = `
  @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
  @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
`;
document.head.appendChild(styleSheet);

export default App;
