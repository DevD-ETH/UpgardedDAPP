//SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "hardhat/console.sol";

contract Sample {
    struct MessageEntry {
        string content;
        uint256 timestamp;
        address author;
        uint256 tips;
        mapping(string => uint256) reactions;
    }

    struct TipEntry {
        address from;
        uint256 amount;
        uint256 timestamp;
        uint256 messageIndex;
    }

    string private message;
    address public owner;
    uint256 public messageCount;
    MessageEntry[] public messageHistory;
    TipEntry[] public allTips;
    mapping(address => uint256) public totalTipsReceived;
    mapping(address => uint256) public totalTipsSent;
    
    string[] public reactionTypes;
    
    event MessageUpdated(string oldMessage, string newMessage, address updatedBy, uint256 timestamp);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event TipSent(address indexed from, address indexed to, uint256 amount, uint256 messageIndex);
    event ReactionAdded(address indexed user, uint256 messageIndex, string reaction, uint256 count);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner can perform this action");
        _;
    }

    constructor(string memory _message) {
        console.log("Deploying a Sample with message:", _message);
        message = _message;
        owner = msg.sender;
        messageCount = 1;
        
        // Initialize reaction types (emoji names - frontend maps these to actual emojis)
        reactionTypes.push("like");
        reactionTypes.push("love");
        reactionTypes.push("laugh");
        reactionTypes.push("wow");
        reactionTypes.push("party");
        
        MessageEntry storage entry = messageHistory.push();
        entry.content = _message;
        entry.timestamp = block.timestamp;
        entry.author = msg.sender;
        entry.tips = 0;
    }

    function getMessage() public view returns (string memory) {
        return message;
    }

    function setMessage(string memory _message) public {
        console.log("Changing message from '%s' to '%s'", message, _message);
        string memory oldMessage = message;
        message = _message;
        messageCount++;
        
        MessageEntry storage entry = messageHistory.push();
        entry.content = _message;
        entry.timestamp = block.timestamp;
        entry.author = msg.sender;
        entry.tips = 0;
        
        emit MessageUpdated(oldMessage, _message, msg.sender, block.timestamp);
    }

    function tipMessageAuthor(uint256 messageIndex) public payable {
        require(messageIndex < messageHistory.length, "Invalid message index");
        require(msg.value > 0, "Tip amount must be greater than 0");
        
        MessageEntry storage entry = messageHistory[messageIndex];
        address author = entry.author;
        require(author != address(0), "Invalid author");
        
        entry.tips += msg.value;
        totalTipsReceived[author] += msg.value;
        totalTipsSent[msg.sender] += msg.value;
        
        allTips.push(TipEntry({
            from: msg.sender,
            amount: msg.value,
            timestamp: block.timestamp,
            messageIndex: messageIndex
        }));
        
        // Transfer tip to author
        (bool sent, ) = author.call{value: msg.value}("");
        require(sent, "Failed to send tip");
        
        emit TipSent(msg.sender, author, msg.value, messageIndex);
    }

    function addReaction(uint256 messageIndex, string memory reaction) public {
        require(messageIndex < messageHistory.length, "Invalid message index");
        require(isValidReaction(reaction), "Invalid reaction type");
        
        MessageEntry storage entry = messageHistory[messageIndex];
        entry.reactions[reaction]++;
        
        emit ReactionAdded(msg.sender, messageIndex, reaction, entry.reactions[reaction]);
    }

    function isValidReaction(string memory reaction) public view returns (bool) {
        for (uint256 i = 0; i < reactionTypes.length; i++) {
            if (keccak256(bytes(reactionTypes[i])) == keccak256(bytes(reaction))) {
                return true;
            }
        }
        return false;
    }

    function getReactionCount(uint256 messageIndex, string memory reaction) public view returns (uint256) {
        require(messageIndex < messageHistory.length, "Invalid message index");
        return messageHistory[messageIndex].reactions[reaction];
    }

    function getMessageTips(uint256 messageIndex) public view returns (uint256) {
        require(messageIndex < messageHistory.length, "Invalid message index");
        return messageHistory[messageIndex].tips;
    }

    function transferOwnership(address newOwner) public onlyOwner {
        require(newOwner != address(0), "New owner cannot be zero address");
        address oldOwner = owner;
        owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }

    function getMessageHistory() public view returns (
        string[] memory contents,
        uint256[] memory timestamps,
        address[] memory authors,
        uint256[] memory tips
    ) {
        uint256 length = messageHistory.length;
        contents = new string[](length);
        timestamps = new uint256[](length);
        authors = new address[](length);
        tips = new uint256[](length);
        
        for (uint256 i = 0; i < length; i++) {
            MessageEntry storage entry = messageHistory[i];
            contents[i] = entry.content;
            timestamps[i] = entry.timestamp;
            authors[i] = entry.author;
            tips[i] = entry.tips;
        }
        
        return (contents, timestamps, authors, tips);
    }

    function getMessageHistoryCount() public view returns (uint256) {
        return messageHistory.length;
    }

    function getMessageAtIndex(uint256 index) public view returns (
        string memory content,
        uint256 timestamp,
        address author,
        uint256 tips
    ) {
        require(index < messageHistory.length, "Index out of bounds");
        MessageEntry storage entry = messageHistory[index];
        return (entry.content, entry.timestamp, entry.author, entry.tips);
    }

    function getCurrentTimestamp() public view returns (uint256) {
        return block.timestamp;
    }

    function getReactionTypes() public view returns (string[] memory) {
        return reactionTypes;
    }

    receive() external payable {
        // Allow contract to receive ETH
    }
}
